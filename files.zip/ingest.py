"""
etl/ingest.py
─────────────
Reads the raw NCUA quarterly .txt files from data/raw/<quarter>/
and writes merged parquet files to data/processed/.

Usage:
    python etl/ingest.py --quarter 2024Q3 --data-dir data/raw/2024Q3

For a flat layout (all files in one folder):
    python etl/ingest.py --quarter 2024Q3 --data-dir data/raw
"""

import argparse
import os
import re
import pandas as pd
from pathlib import Path

# ── File → logical name map ──────────────────────────────────────────────────
FILE_MAP = {
    "FOICU.txt":                           "profile",
    "FOICUDES.txt":                        "profile_des",
    "FS220.txt":                           "fs220",
    "FS220A.txt":                          "fs220a",
    "FS220B.txt":                          "fs220b",
    "FS220C.txt":                          "fs220c",
    "FS220D.txt":                          "fs220d",
    "FS220G.txt":                          "fs220g",
    "FS220H.txt":                          "fs220h",
    "FS220I.txt":                          "fs220i",
    "FS220J.txt":                          "fs220j",
    "FS220K.txt":                          "fs220k",
    "FS220L.txt":                          "fs220l",
    "FS220M.txt":                          "fs220m",
    "AcctDesc.txt":                        "acct_desc",
    "Acct-DescTradeNames.txt":             "acct_trade",
    "Credit Union Branch Information.txt": "branches",
    "ATM Locations.txt":                   "atm",
}

# ── Schedule descriptions (for UI labels) ───────────────────────────────────
SCHEDULE_LABELS = {
    "fs220":  "Balance Sheet & Income Statement",
    "fs220a": "Schedule A – Loans",
    "fs220b": "Schedule B – Investments",
    "fs220c": "Schedule C – Shares",
    "fs220d": "Schedule D – Capital",
    "fs220g": "Schedule G – Delinquent Loans",
    "fs220h": "Schedule H – Borrowed Funds",
    "fs220i": "Schedule I – Off-Balance Sheet",
    "fs220j": "Schedule J – Members & Surveys",
    "fs220k": "Schedule K – Derivatives",
    "fs220l": "Schedule L – Liquidity",
    "fs220m": "Schedule M – Credit Risk",
}


def read_txt(path: Path, encoding: str = "latin-1") -> pd.DataFrame:
    """Read a pipe- or comma-delimited NCUA txt file into a DataFrame."""
    try:
        # Try pipe first (most NCUA files), fallback to comma
        df = pd.read_csv(path, sep="|", encoding=encoding, low_memory=False)
        if df.shape[1] <= 1:
            df = pd.read_csv(path, sep=",", encoding=encoding, low_memory=False)
    except Exception as e:
        print(f"  ✗ Could not read {path.name}: {e}")
        return pd.DataFrame()

    # Normalize column names
    df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]
    return df


def add_quarter_col(df: pd.DataFrame, quarter: str) -> pd.DataFrame:
    """Stamp every row with the quarter string e.g. '2024Q3'."""
    df.insert(0, "quarter", quarter)
    return df


def ingest(quarter: str, data_dir: str, out_dir: str = "data/processed"):
    data_path = Path(data_dir)
    out_path  = Path(out_dir)
    out_path.mkdir(parents=True, exist_ok=True)

    print(f"\n▶  Ingesting quarter: {quarter}  from  {data_path}\n")

    results = {}
    for filename, key in FILE_MAP.items():
        filepath = data_path / filename
        if not filepath.exists():
            print(f"  – {filename:<45} not found, skipping")
            continue

        df = read_txt(filepath)
        if df.empty:
            continue

        df = add_quarter_col(df, quarter)
        results[key] = df
        print(f"  ✓ {filename:<45} {len(df):>7,} rows  {len(df.columns)} cols")

    # ── Append or create parquet per table ──────────────────────────────────
    for key, df in results.items():
        parquet_file = out_path / f"{key}.parquet"

        if parquet_file.exists():
            existing = pd.read_parquet(parquet_file)
            # Drop existing rows for this quarter before appending (idempotent)
            existing = existing[existing["quarter"] != quarter]
            df = pd.concat([existing, df], ignore_index=True)

        df.to_parquet(parquet_file, index=False)
        print(f"  💾 Saved {key}.parquet  ({len(df):,} total rows)")

    print(f"\n✅  Done — {len(results)} tables written to {out_path}\n")
    return results


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Ingest NCUA quarterly files")
    parser.add_argument("--quarter",  required=True,  help="e.g. 2024Q3")
    parser.add_argument("--data-dir", required=True,  help="path to folder with .txt files")
    parser.add_argument("--out-dir",  default="data/processed", help="output dir for parquets")
    args = parser.parse_args()

    ingest(args.quarter, args.data_dir, args.out_dir)
