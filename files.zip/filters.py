"""
utils/filters.py
────────────────
Reusable Streamlit filter widgets and DataFrame display helpers
shared across all pages.
"""

import streamlit as st
import pandas as pd
from utils.loader import get_quarters, get_latest_quarter, cu_search_options


# ── Quarter selector ─────────────────────────────────────────────────────────
def quarter_selector(key="quarter_sel", label="Quarter") -> str | None:
    quarters = get_quarters()
    if not quarters:
        st.warning("No data loaded yet. Visit ⚙️ Admin to load data.")
        return None
    idx = len(quarters) - 1
    return st.selectbox(label, quarters, index=idx, key=key)


# ── CU search / select ───────────────────────────────────────────────────────
def cu_selector(quarter: str | None = None, key="cu_sel", label="Search credit union") -> str | None:
    """
    Returns the selected cu_number string, or None.
    Shows a searchable selectbox with name + charter number.
    """
    df = cu_search_options(quarter)
    if df.empty:
        st.warning("No credit union data available.")
        return None

    if "cu_name" in df.columns and "cu_number" in df.columns:
        options = df.sort_values("cu_name")
        display = options.apply(lambda r: f"{r['cu_name']}  ({r['cu_number']})", axis=1).tolist()
        numbers = options["cu_number"].tolist()
    elif "cu_name" in df.columns:
        options  = df.sort_values("cu_name")
        display  = options["cu_name"].tolist()
        numbers  = display
    else:
        display = df.iloc[:, 0].tolist()
        numbers = display

    choice = st.selectbox(label, display, key=key)
    if choice is None:
        return None
    idx = display.index(choice)
    return str(numbers[idx])


# ── State filter ─────────────────────────────────────────────────────────────
def state_filter(df: pd.DataFrame, key="state_filter") -> pd.DataFrame:
    if "state" not in df.columns:
        return df
    states = ["All"] + sorted(df["state"].dropna().unique().tolist())
    sel = st.selectbox("State", states, key=key)
    if sel != "All":
        df = df[df["state"] == sel]
    return df


# ── Asset size bucket ─────────────────────────────────────────────────────────
ASSET_BUCKETS = {
    "All sizes":            (0,           float("inf")),
    "< $10M":               (0,           10_000),
    "$10M – $50M":          (10_000,      50_000),
    "$50M – $100M":         (50_000,      100_000),
    "$100M – $500M":        (100_000,     500_000),
    "$500M – $1B":          (500_000,     1_000_000),
    "> $1B":                (1_000_000,   float("inf")),
}

def asset_size_filter(df: pd.DataFrame, asset_col: str = "acct_010", key="asset_filter") -> pd.DataFrame:
    if asset_col not in df.columns:
        return df
    label = st.selectbox("Asset size", list(ASSET_BUCKETS.keys()), key=key)
    low, high = ASSET_BUCKETS[label]
    if label != "All sizes":
        df = df[df[asset_col].between(low, high, inclusive="both")]
    return df


# ── Pretty dataframe display ──────────────────────────────────────────────────
def show_table(df: pd.DataFrame, height: int = 400, hide_index: bool = True):
    """Render a DataFrame with consistent styling."""
    st.dataframe(
        df,
        use_container_width=True,
        height=height,
        hide_index=hide_index,
    )


# ── Metric card HTML ──────────────────────────────────────────────────────────
def metric_card(label: str, value: str, delta: str | None = None, delta_positive: bool = True):
    delta_html = ""
    if delta:
        cls   = "metric-delta-pos" if delta_positive else "metric-delta-neg"
        arrow = "▲" if delta_positive else "▼"
        delta_html = f'<div class="{cls}">{arrow} {delta}</div>'

    st.markdown(f"""
    <div class="metric-card">
      <div class="metric-label">{label}</div>
      <div class="metric-value">{value}</div>
      {delta_html}
    </div>
    """, unsafe_allow_html=True)


# ── No-data message ───────────────────────────────────────────────────────────
def no_data_msg(message: str = "No data available for this selection."):
    st.info(message, icon="ℹ️")
