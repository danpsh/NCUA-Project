"""
pages/1_CU_Search.py
─────────────────────
Search for a credit union and view its full call report profile.
Mirrors the NCUA 5300 structure with a better UI.
"""

import streamlit as st
import pandas as pd
from utils.loader  import load_profile, load_fs220, load_schedule, load_branches
from utils.metrics import calc_all, fmt_currency, fmt_pct, fmt_number
from utils.filters import quarter_selector, cu_selector, metric_card, no_data_msg

st.set_page_config(page_title="CU Search | NCUA Dashboard", layout="wide")

st.title("🔍 Credit Union Search & Profile")

# ── Selectors ────────────────────────────────────────────────────────────────
col1, col2 = st.columns([1, 2])
with col1:
    quarter = quarter_selector(key="cu_qsel")
with col2:
    cu_number = cu_selector(quarter=quarter, key="cu_cusel")

if not cu_number or not quarter:
    no_data_msg("Select a quarter and credit union above.")
    st.stop()

# ── Load profile row ─────────────────────────────────────────────────────────
profile_df = load_profile()
if profile_df.empty:
    no_data_msg("Profile data not loaded. Visit ⚙️ Admin.")
    st.stop()

# Normalize cu_number column name
for col in profile_df.columns:
    if "cu_number" in col.lower() or col.lower() == "charter_number":
        profile_df = profile_df.rename(columns={col: "cu_number"})
        break

mask = (profile_df["quarter"] == quarter) & (profile_df["cu_number"].astype(str) == str(cu_number))
cu_row = profile_df[mask]

if cu_row.empty:
    no_data_msg(f"No profile data found for CU {cu_number} in {quarter}.")
    st.stop()

cu = cu_row.iloc[0]

# ── CU Header ────────────────────────────────────────────────────────────────
cu_name = cu.get("cu_name", cu.get("credit_union_name", f"CU #{cu_number}"))
st.markdown(f"## {cu_name}")

info_cols = st.columns(4)
fields = [
    ("Charter #",     "cu_number"),
    ("State",         "state"),
    ("Charter Type",  "charter_type"),
    ("Field of Membership", "field_of_membership"),
]
for i, (label, field) in enumerate(fields):
    with info_cols[i % 4]:
        val = cu.get(field, "—")
        st.metric(label, val if pd.notna(val) else "—")

st.markdown("---")

# ── Key Ratios ───────────────────────────────────────────────────────────────
fs220_df = load_fs220()
if not fs220_df.empty:
    mask2 = (fs220_df["quarter"] == quarter) & (fs220_df.get("cu_number", fs220_df.iloc[:, 1]).astype(str) == str(cu_number))
    fin_row = fs220_df[mask2]

    if not fin_row.empty:
        frow = fin_row.iloc[0]
        metrics = calc_all(frow)

        st.markdown('<div class="section-header">Key Ratios</div>', unsafe_allow_html=True)
        mcols = st.columns(6)
        for i, (key, m) in enumerate(metrics.items()):
            with mcols[i]:
                metric_card(m["label"], fmt_pct(m["value"]) if m["value"] is not None else "—")

        # ── Financial summary ────────────────────────────────────────────────
        st.markdown('<div class="section-header">Financial Summary</div>', unsafe_allow_html=True)
        fcols = st.columns(4)
        summary_fields = [
            ("Total Assets",   "acct_010"),
            ("Total Loans",    "acct_025b"),
            ("Total Shares",   "acct_018"),
            ("Net Worth",      "acct_891"),
        ]
        for i, (label, field) in enumerate(summary_fields):
            with fcols[i]:
                val = frow.get(field)
                metric_card(label, fmt_currency(val) if pd.notna(val) else "—")

# ── Schedule tabs ────────────────────────────────────────────────────────────
st.markdown('<div class="section-header">Call Report Schedules</div>', unsafe_allow_html=True)

SCHEDULES = {
    "Balance Sheet (FS220)": "fs220",
    "Loans (A)":             "fs220a",
    "Investments (B)":       "fs220b",
    "Shares (C)":            "fs220c",
    "Capital (D)":           "fs220d",
    "Delinquency (G)":       "fs220g",
    "Borrowed Funds (H)":    "fs220h",
    "Members (J)":           "fs220j",
}

tabs = st.tabs(list(SCHEDULES.keys()))
for tab, (tab_label, sched_key) in zip(tabs, SCHEDULES.items()):
    with tab:
        sched_df = load_fs220() if sched_key == "fs220" else load_schedule(sched_key)
        if sched_df.empty:
            st.caption(f"No data for {tab_label}.")
            continue

        # Find this CU's row
        id_col = next((c for c in sched_df.columns if "cu_number" in c.lower()), sched_df.columns[1])
        mask3  = (sched_df["quarter"] == quarter) & (sched_df[id_col].astype(str) == str(cu_number))
        rows   = sched_df[mask3]

        if rows.empty:
            st.caption("No data for this CU in this schedule.")
            continue

        # Transpose: fields as rows, value as column
        row_t = rows.iloc[0].drop("quarter").rename("Value").reset_index()
        row_t.columns = ["Field", "Value"]
        row_t = row_t[row_t["Field"] != id_col]
        st.dataframe(row_t, use_container_width=True, hide_index=True, height=350)

# ── Branch info ──────────────────────────────────────────────────────────────
branches_df = load_branches()
if not branches_df.empty:
    st.markdown('<div class="section-header">Branch Locations</div>', unsafe_allow_html=True)
    id_col = next((c for c in branches_df.columns if "cu_number" in c.lower()), branches_df.columns[0])
    b_rows = branches_df[branches_df[id_col].astype(str) == str(cu_number)]
    if not b_rows.empty:
        st.dataframe(b_rows.drop(columns=["quarter"], errors="ignore"), use_container_width=True, hide_index=True)
    else:
        st.caption("No branch data for this CU.")
