"""
utils/loader.py
───────────────
Cached data loading functions for all Streamlit pages.
All functions use @st.cache_data so data is loaded once per session.
"""

import streamlit as st
import pandas as pd
from pathlib import Path

PROCESSED_DIR = Path("data/processed")


def _load(table: str) -> pd.DataFrame:
    path = PROCESSED_DIR / f"{table}.parquet"
    if not path.exists():
        return pd.DataFrame()
    return pd.read_parquet(path)


@st.cache_data(ttl=3600, show_spinner="Loading credit union profiles…")
def load_profile() -> pd.DataFrame:
    return _load("profile")


@st.cache_data(ttl=3600, show_spinner="Loading call report data…")
def load_fs220() -> pd.DataFrame:
    return _load("fs220")


@st.cache_data(ttl=3600, show_spinner="Loading schedule data…")
def load_schedule(schedule: str) -> pd.DataFrame:
    """Load any FS220 schedule. schedule = 'fs220a', 'fs220b', etc."""
    return _load(schedule)


@st.cache_data(ttl=3600, show_spinner="Loading branch data…")
def load_branches() -> pd.DataFrame:
    return _load("branches")


@st.cache_data(ttl=3600, show_spinner="Loading ATM data…")
def load_atm() -> pd.DataFrame:
    return _load("atm")


@st.cache_data(ttl=3600, show_spinner="Loading account descriptions…")
def load_acct_desc() -> pd.DataFrame:
    return _load("acct_desc")


def get_quarters() -> list[str]:
    """Return sorted list of available quarters across all loaded data."""
    df = load_profile()
    if df.empty or "quarter" not in df.columns:
        return []
    return sorted(df["quarter"].unique().tolist())


def get_latest_quarter() -> str | None:
    quarters = get_quarters()
    return quarters[-1] if quarters else None


def data_is_loaded() -> bool:
    """Quick check — returns True if at least the profile parquet exists."""
    return (PROCESSED_DIR / "profile.parquet").exists()


def cu_search_options(quarter: str | None = None) -> pd.DataFrame:
    """
    Return a lightweight DataFrame for CU search/select widgets.
    Columns: cu_number, cu_name, state, asset_size_group, charter_type
    """
    df = load_profile()
    if df.empty:
        return df

    if quarter and "quarter" in df.columns:
        df = df[df["quarter"] == quarter]

    # Normalize likely NCUA column names (vary slightly between years)
    rename = {}
    for col in df.columns:
        lc = col.lower()
        if "cu_number" in lc or lc == "charter_number":
            rename[col] = "cu_number"
        elif "cu_name" in lc or lc == "credit_union_name":
            rename[col] = "cu_name"
        elif lc in ("state", "state_code", "cu_state"):
            rename[col] = "state"
    df = df.rename(columns=rename)

    keep = [c for c in ["quarter", "cu_number", "cu_name", "state"] if c in df.columns]
    return df[keep].drop_duplicates(subset=["cu_number"] if "cu_number" in df.columns else None)
