import streamlit as st

st.set_page_config(
    page_title="NCUA Credit Union Dashboard",
    page_icon="🏦",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── Global CSS ──────────────────────────────────────────────────────────────
st.markdown("""
<style>
  [data-testid="stSidebar"] { background: #0d1117; }
  [data-testid="stSidebar"] * { color: #e6edf3 !important; }
  .metric-card {
    background: #161b22; border: 1px solid #30363d;
    border-radius: 8px; padding: 16px 20px; margin-bottom: 8px;
  }
  .metric-label { font-size: 11px; color: #8b949e; text-transform: uppercase; letter-spacing: .08em; }
  .metric-value { font-size: 26px; font-weight: 700; color: #e6edf3; margin-top: 2px; }
  .metric-delta-pos { color: #3fb950; font-size: 12px; }
  .metric-delta-neg { color: #f85149; font-size: 12px; }
  .section-header {
    font-size: 13px; font-weight: 600; color: #8b949e;
    text-transform: uppercase; letter-spacing: .1em;
    border-bottom: 1px solid #21262d; padding-bottom: 6px; margin: 20px 0 12px;
  }
  div[data-testid="stDataFrame"] { border: 1px solid #30363d; border-radius: 8px; }
</style>
""", unsafe_allow_html=True)

# ── Sidebar ──────────────────────────────────────────────────────────────────
with st.sidebar:
    st.markdown("## 🏦 NCUA Dashboard")
    st.markdown("---")
    st.markdown("**Navigation**")
    st.page_link("pages/1_CU_Search.py",      label="🔍  CU Search & Profile")
    st.page_link("pages/2_Peer_Compare.py",   label="📊  Peer Comparison")
    st.page_link("pages/3_Trends.py",         label="📈  Trend Analysis")
    st.page_link("pages/4_Data_Explorer.py",  label="🗂️   Data Explorer")
    st.markdown("---")
    st.markdown("**Data**")
    st.page_link("pages/5_Admin.py",          label="⚙️   Admin / Load Data")

# ── Home landing ─────────────────────────────────────────────────────────────
st.title("NCUA Credit Union Dashboard")
st.markdown("Select a page from the sidebar to get started.")

col1, col2, col3, col4 = st.columns(4)
with col1:
    st.markdown("""<div class="metric-card">
      <div class="metric-label">CU Search</div>
      <div class="metric-value">🔍</div>
      <div style="color:#8b949e;font-size:13px;margin-top:6px">Find any credit union, view full call report</div>
    </div>""", unsafe_allow_html=True)
with col2:
    st.markdown("""<div class="metric-card">
      <div class="metric-label">Peer Compare</div>
      <div class="metric-value">📊</div>
      <div style="color:#8b949e;font-size:13px;margin-top:6px">Benchmark vs cohort by size, state, charter</div>
    </div>""", unsafe_allow_html=True)
with col3:
    st.markdown("""<div class="metric-card">
      <div class="metric-label">Trend Analysis</div>
      <div class="metric-value">📈</div>
      <div style="color:#8b949e;font-size:13px;margin-top:6px">Track any metric across quarters</div>
    </div>""", unsafe_allow_html=True)
with col4:
    st.markdown("""<div class="metric-card">
      <div class="metric-label">Data Explorer</div>
      <div class="metric-value">🗂️</div>
      <div style="color:#8b949e;font-size:13px;margin-top:6px">Filter, sort, and export raw data</div>
    </div>""", unsafe_allow_html=True)
