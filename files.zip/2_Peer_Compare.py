"""
pages/2_Peer_Compare.py
───────────────────────
Compare a credit union against a peer cohort.
Cohort built by: asset size, state, charter type.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils.loader  import load_profile, load_fs220
from utils.metrics import (net_worth_ratio, roa, loan_to_share,
                            delinquency_rate, fmt_pct, fmt_currency)
from utils.filters import quarter_selector, cu_selector, no_data_msg

st.set_page_config(page_title="Peer Compare | NCUA Dashboard", layout="wide")
st.title("📊 Peer Comparison")

# ── Selectors ────────────────────────────────────────────────────────────────
c1, c2 = st.columns([1, 2])
with c1:
    quarter = quarter_selector(key="peer_qsel")
with c2:
    cu_number = cu_selector(quarter=quarter, key="peer_cusel")

if not cu_number or not quarter:
    no_data_msg()
    st.stop()

# ── Load data ─────────────────────────────────────────────────────────────────
profile_df = load_profile()
fs220_df   = load_fs220()

if profile_df.empty or fs220_df.empty:
    no_data_msg("Profile or financial data not loaded. Visit ⚙️ Admin.")
    st.stop()

# Normalize column names
for col in profile_df.columns:
    if "cu_number" in col.lower():
        profile_df = profile_df.rename(columns={col: "cu_number"})
        break

prof_q = profile_df[profile_df["quarter"] == quarter].copy()
fin_q  = fs220_df[fs220_df["quarter"] == quarter].copy()

# Identify CU's profile row
this_cu = prof_q[prof_q["cu_number"].astype(str) == str(cu_number)]
if this_cu.empty:
    no_data_msg(f"No profile data for CU {cu_number} in {quarter}.")
    st.stop()

this_cu_row = this_cu.iloc[0]
cu_name     = this_cu_row.get("cu_name", f"CU {cu_number}")

# ── Cohort builder ────────────────────────────────────────────────────────────
st.markdown("### Build peer cohort")
cc1, cc2, cc3 = st.columns(3)

asset_col = next((c for c in fin_q.columns if c == "acct_010"), None)

with cc1:
    state_match = st.checkbox("Same state", value=True)
with cc2:
    charter_match = st.checkbox("Same charter type", value=False)
with cc3:
    size_match = st.checkbox("Similar asset size (±50%)", value=True)

cohort = prof_q.copy()
if state_match and "state" in cohort.columns:
    cohort = cohort[cohort["state"] == this_cu_row.get("state")]
if charter_match and "charter_type" in cohort.columns:
    cohort = cohort[cohort["charter_type"] == this_cu_row.get("charter_type")]

# Merge in financial data to apply asset size filter
id_col_fin = next((c for c in fin_q.columns if "cu_number" in c.lower()), fin_q.columns[1])
fin_q2 = fin_q.rename(columns={id_col_fin: "cu_number"})
merged = cohort.merge(fin_q2, on="cu_number", how="inner", suffixes=("", "_fin"))

if size_match and asset_col and asset_col in merged.columns:
    this_assets = merged[merged["cu_number"].astype(str) == str(cu_number)][asset_col]
    if not this_assets.empty:
        ta = float(this_assets.iloc[0])
        merged = merged[merged[asset_col].between(ta * 0.5, ta * 1.5)]

st.caption(f"Cohort size: **{len(merged):,}** credit unions")

# ── Compute metrics for all cohort CUs ───────────────────────────────────────
metric_funcs = {
    "Net Worth Ratio (%)":  net_worth_ratio,
    "ROA (%)":              roa,
    "Loan-to-Share (%)":    loan_to_share,
    "Delinquency Rate (%)": delinquency_rate,
}

rows = []
for _, row in merged.iterrows():
    entry = {"cu_number": row["cu_number"], "cu_name": row.get("cu_name", "")}
    for name, fn in metric_funcs.items():
        entry[name] = fn(row)
    rows.append(entry)

compare_df = pd.DataFrame(rows)

# ── Display comparison table ──────────────────────────────────────────────────
st.markdown("---")
st.markdown("### Cohort comparison")

# Highlight selected CU
def highlight_cu(row):
    if str(row["cu_number"]) == str(cu_number):
        return ["background-color: #1f3a52"] * len(row)
    return [""] * len(row)

display_df = compare_df.drop(columns=["cu_number"]).sort_values("Net Worth Ratio (%)", ascending=False)
st.dataframe(
    display_df.style.apply(
        lambda row: ["background-color: #1f3a52" if compare_df.iloc[row.name]["cu_number"] == cu_number else "" for _ in row],
        axis=1
    ),
    use_container_width=True,
    hide_index=True,
    height=400,
)

# ── Box plot comparison ───────────────────────────────────────────────────────
st.markdown("### Distribution vs. peers")

metric_choice = st.selectbox("Select metric", list(metric_funcs.keys()))
vals = compare_df[metric_choice].dropna()
this_val = compare_df[compare_df["cu_number"].astype(str) == str(cu_number)][metric_choice]

fig = go.Figure()
fig.add_trace(go.Box(
    y=vals,
    name="Cohort",
    boxmean=True,
    marker_color="#388bfd",
    line_color="#388bfd",
))
if not this_val.empty:
    fig.add_trace(go.Scatter(
        y=[this_val.iloc[0]],
        x=["Cohort"],
        mode="markers",
        marker=dict(color="#f0883e", size=14, symbol="diamond"),
        name=cu_name,
    ))

fig.update_layout(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="#0d1117",
    font_color="#e6edf3",
    height=360,
    showlegend=True,
    yaxis=dict(gridcolor="#21262d"),
    xaxis=dict(gridcolor="#21262d"),
    margin=dict(l=20, r=20, t=20, b=20),
)
st.plotly_chart(fig, use_container_width=True)
