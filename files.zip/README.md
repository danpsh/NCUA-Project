# NCUA Credit Union Dashboard

A Streamlit app for exploring NCUA quarterly call report data with a better UI than the official site.

## Setup

```bash
pip install -r requirements.txt
```

## Loading data

1. Drop your NCUA quarterly `.txt` files into `data/raw/` (or a subfolder like `data/raw/2024Q3/`)
2. Run the ETL ingest:

```bash
# Files flat in data/raw/
python etl/ingest.py --quarter 2024Q3 --data-dir data/raw

# Files in a quarter subfolder
python etl/ingest.py --quarter 2024Q3 --data-dir data/raw/2024Q3
```

Or use the **⚙️ Admin** page in the app to run ingest from the UI.

## Running

```bash
streamlit run app.py
```

## Adding more quarters

Repeat the ingest step with a new `--quarter` label. The ETL appends to existing parquets automatically (and is idempotent — re-running the same quarter replaces it cleanly).

## Repo structure

```
ncua-dashboard/
├── app.py                    # Entry point + sidebar
├── etl/
│   └── ingest.py             # NCUA .txt → parquet pipeline
├── pages/
│   ├── 1_CU_Search.py        # CU profile & call report viewer
│   ├── 2_Peer_Compare.py     # Peer benchmarking
│   ├── 3_Trends.py           # Multi-quarter trend charts
│   ├── 4_Data_Explorer.py    # Filter / export raw data
│   └── 5_Admin.py            # Data management
├── utils/
│   ├── loader.py             # Cached data loading
│   ├── metrics.py            # Ratio calculations
│   └── filters.py            # Shared UI widgets
├── data/
│   raw/                      # Drop .txt files here
│   processed/                # Auto-generated parquets (gitignored)
├── .streamlit/config.toml    # Dark theme
└── requirements.txt
```

## NCUA file reference

| File | Contents |
|------|----------|
| FOICU.txt | Credit union profile (name, address, charter, assets) |
| FOICUDES.txt | Field descriptions |
| FS220.txt | Main balance sheet & income statement |
| FS220A.txt | Schedule A – Loans |
| FS220B.txt | Schedule B – Investments |
| FS220C.txt | Schedule C – Shares/Deposits |
| FS220D.txt | Schedule D – Capital |
| FS220G.txt | Schedule G – Delinquent Loans |
| FS220H.txt | Schedule H – Borrowed Funds |
| FS220I.txt | Schedule I – Off-Balance Sheet |
| FS220J.txt | Schedule J – Members & Surveys |
| FS220K.txt | Schedule K – Derivatives |
| FS220L.txt | Schedule L – Liquidity |
| FS220M.txt | Schedule M – Credit Risk |
| AcctDesc.txt | Account code definitions |
| Credit Union Branch Information.txt | Branch locations |
| ATM Locations.txt | ATM data |
