"""
pages/4_Data_Explorer.py
─────────────────────────
Filter, sort, and export raw NCUA data across all loaded tables.
"""

import streamlit as st
import pandas as pd
from utils.loader  import load_profile, load_fs220, load_schedule, load_branches, load_atm
from utils.filters import quarter_selector, state_filter, no_data_msg

st.set_page_config(page_title="Data Explorer | NCUA Dashboard", layout="wide")
st.title("🗂️ Data Explorer")

# ── Table picker ──────────────────────────────────────────────────────────────
TABLE_OPTIONS = {
    "Credit Union Profile (FOICU)":   "profile",
    "Balance Sheet & Income (FS220)": "fs220",
    "Schedule A – Loans":             "fs220a",
    "Schedule B – Investments":       "fs220b",
    "Schedule C – Shares":            "fs220c",
    "Schedule D – Capital":           "fs220d",
    "Schedule G – Delinquency":       "fs220g",
    "Schedule H – Borrowed Funds":    "fs220h",
    "Schedule J – Members":           "fs220j",
    "Branch Information":             "branches",
    "ATM Locations":                  "atm",
}

c1, c2 = st.columns([2, 1])
with c1:
    table_label = st.selectbox("Table", list(TABLE_OPTIONS.keys()))
with c2:
    quarter = quarter_selector(key="exp_qsel")

table_key = TABLE_OPTIONS[table_label]

# ── Load ──────────────────────────────────────────────────────────────────────
LOADERS = {
    "profile":  load_profile,
    "fs220":    load_fs220,
    "branches": load_branches,
    "atm":      load_atm,
}

if table_key in LOADERS:
    df = LOADERS[table_key]()
else:
    df = load_schedule(table_key)

if df.empty:
    no_data_msg(f"No data for {table_label}. Run ETL ingest first.")
    st.stop()

# Filter by quarter
if quarter and "quarter" in df.columns:
    df = df[df["quarter"] == quarter]

# ── Column filter ─────────────────────────────────────────────────────────────
with st.expander("🔧 Column & filter options", expanded=False):
    all_cols   = df.columns.tolist()
    show_cols  = st.multiselect("Columns to display", all_cols, default=all_cols[:min(15, len(all_cols))])
    if not show_cols:
        show_cols = all_cols

    # State filter if available
    if "state" in df.columns:
        states = ["All"] + sorted(df["state"].dropna().unique().tolist())
        sel_state = st.selectbox("State", states, key="exp_state")
        if sel_state != "All":
            df = df[df["state"] == sel_state]

    # Free text search
    search = st.text_input("Search (filters all text columns)", "")
    if search:
        mask = df.astype(str).apply(lambda col: col.str.contains(search, case=False, na=False)).any(axis=1)
        df   = df[mask]

# ── Display ───────────────────────────────────────────────────────────────────
st.caption(f"**{len(df):,}** rows  ·  {len(show_cols)} columns shown")

st.dataframe(
    df[show_cols],
    use_container_width=True,
    height=500,
    hide_index=True,
)

# ── Export ────────────────────────────────────────────────────────────────────
col_dl1, col_dl2, _ = st.columns([1, 1, 4])
with col_dl1:
    csv = df[show_cols].to_csv(index=False).encode("utf-8")
    st.download_button(
        label="⬇️ Download CSV",
        data=csv,
        file_name=f"{table_key}_{quarter or 'all'}.csv",
        mime="text/csv",
    )
with col_dl2:
    try:
        import io
        buf = io.BytesIO()
        df[show_cols].to_excel(buf, index=False)
        st.download_button(
            label="⬇️ Download Excel",
            data=buf.getvalue(),
            file_name=f"{table_key}_{quarter or 'all'}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        )
    except ImportError:
        st.caption("Install `openpyxl` for Excel export.")
