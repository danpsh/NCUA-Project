"""
utils/metrics.py
────────────────
Key ratio and metric calculations from NCUA 5300 call report fields.
All functions accept a dict or Series of raw field values and return
a dict of calculated metrics ready for display.
"""

import pandas as pd
import numpy as np


# ── Field name helpers ───────────────────────────────────────────────────────
def _get(row, *keys, default=0):
    """Try multiple possible field names; return first match or default."""
    for k in keys:
        for col in (k, k.lower(), k.upper()):
            if col in row.index and pd.notna(row[col]):
                try:
                    return float(row[col])
                except (ValueError, TypeError):
                    pass
    return default


# ── Core ratios ──────────────────────────────────────────────────────────────
def net_worth_ratio(row) -> float | None:
    """Net worth / total assets (%)"""
    nw     = _get(row, "acct_891", "net_worth")
    assets = _get(row, "acct_010", "total_assets")
    return round((nw / assets) * 100, 2) if assets else None


def roa(row) -> float | None:
    """Return on assets: net income / avg total assets (%)"""
    income = _get(row, "acct_661a", "net_income", "acct_661")
    assets = _get(row, "acct_010", "total_assets")
    return round((income / assets) * 100, 2) if assets else None


def loan_to_share(row) -> float | None:
    """Total loans / total shares (%)"""
    loans  = _get(row, "acct_025b", "total_loans")
    shares = _get(row, "acct_018", "total_shares")
    return round((loans / shares) * 100, 2) if shares else None


def delinquency_rate(row) -> float | None:
    """Delinquent loans / total loans (%)"""
    delinq = _get(row, "acct_748", "delinquent_loans")
    loans  = _get(row, "acct_025b", "total_loans")
    return round((delinq / loans) * 100, 2) if loans else None


def charge_off_rate(row) -> float | None:
    """Net charge-offs / average loans (%)"""
    co    = _get(row, "acct_551", "charge_offs")
    loans = _get(row, "acct_025b", "total_loans")
    return round((co / loans) * 100, 2) if loans else None


def operating_expense_ratio(row) -> float | None:
    """Operating expense / average assets (%)"""
    opex   = _get(row, "acct_640", "operating_expense")
    assets = _get(row, "acct_010", "total_assets")
    return round((opex / assets) * 100, 2) if assets else None


def member_growth(current_row, prior_row) -> float | None:
    """YoY member growth (%)"""
    curr = _get(current_row, "acct_083", "number_of_members")
    prev = _get(prior_row,   "acct_083", "number_of_members")
    return round(((curr - prev) / prev) * 100, 2) if prev else None


# ── Capital adequacy thresholds (NCUA PCA) ──────────────────────────────────
def nw_classification(nw_pct: float | None) -> tuple[str, str]:
    """
    Returns (label, color) based on NCUA net worth classification.
    """
    if nw_pct is None:
        return "Unknown", "#8b949e"
    if nw_pct >= 7.0:
        return "Well Capitalized", "#3fb950"
    elif nw_pct >= 6.0:
        return "Adequately Capitalized", "#d29922"
    elif nw_pct >= 4.0:
        return "Undercapitalized", "#f0883e"
    else:
        return "Significantly Undercapitalized", "#f85149"


# ── Summary metrics bundle ───────────────────────────────────────────────────
def calc_all(row) -> dict:
    """
    Calculate all key metrics for a single CU row.
    Returns a dict suitable for display cards.
    """
    nw  = net_worth_ratio(row)
    nw_label, nw_color = nw_classification(nw)

    return {
        "net_worth_ratio":       {"value": nw,    "label": "Net Worth Ratio",        "fmt": "pct", "classification": nw_label, "color": nw_color},
        "roa":                   {"value": roa(row),                   "label": "Return on Assets",       "fmt": "pct"},
        "loan_to_share":         {"value": loan_to_share(row),         "label": "Loan-to-Share",          "fmt": "pct"},
        "delinquency_rate":      {"value": delinquency_rate(row),      "label": "Delinquency Rate",       "fmt": "pct"},
        "charge_off_rate":       {"value": charge_off_rate(row),       "label": "Net Charge-off Rate",    "fmt": "pct"},
        "operating_expense":     {"value": operating_expense_ratio(row),"label": "Operating Expense Ratio","fmt": "pct"},
    }


# ── Formatting helpers ───────────────────────────────────────────────────────
def fmt_currency(v, abbreviate=True) -> str:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "—"
    v = float(v)
    if abbreviate:
        if abs(v) >= 1_000_000_000:
            return f"${v/1_000_000_000:.2f}B"
        elif abs(v) >= 1_000_000:
            return f"${v/1_000_000:.1f}M"
        elif abs(v) >= 1_000:
            return f"${v/1_000:.0f}K"
    return f"${v:,.0f}"


def fmt_pct(v, decimals=2) -> str:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "—"
    return f"{v:.{decimals}f}%"


def fmt_number(v) -> str:
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "—"
    return f"{int(v):,}"
