"""
pages/3_Trends.py
──────────────────
Track any financial metric across quarters for one or more CUs.
"""

import streamlit as st
import pandas as pd
import plotly.graph_objects as go
from utils.loader  import load_fs220, load_profile, get_quarters
from utils.filters import cu_selector, no_data_msg

st.set_page_config(page_title="Trends | NCUA Dashboard", layout="wide")
st.title("📈 Trend Analysis")

quarters = get_quarters()
if not quarters:
    no_data_msg("No data loaded. Visit ⚙️ Admin.")
    st.stop()

if len(quarters) < 2:
    st.info("Only one quarter loaded. Add more quarterly data to see trends.", icon="ℹ️")

# ── CU selector (multi) ───────────────────────────────────────────────────────
st.markdown("### Select credit unions to compare")
c1, c2 = st.columns([2, 1])
with c1:
    cu1 = cu_selector(key="trend_cu1", label="Primary credit union")
with c2:
    add_second = st.checkbox("Add comparison CU")

cu2 = None
if add_second:
    cu2 = cu_selector(key="trend_cu2", label="Comparison credit union")

selected_cus = [c for c in [cu1, cu2] if c]

# ── Field selector ────────────────────────────────────────────────────────────
fs220_df = load_fs220()
if fs220_df.empty:
    no_data_msg("Financial data not loaded.")
    st.stop()

# Build field options from column names
LABELED_FIELDS = {
    "Total Assets":            "acct_010",
    "Total Loans":             "acct_025b",
    "Total Shares":            "acct_018",
    "Net Worth":               "acct_891",
    "Net Income":              "acct_661a",
    "Operating Expense":       "acct_640",
    "Delinquent Loans":        "acct_748",
    "Net Charge-offs":         "acct_551",
    "Number of Members":       "acct_083",
    "Number of Borrowers":     "acct_084",
}

# Only show fields that exist in the data
available = {k: v for k, v in LABELED_FIELDS.items() if v in fs220_df.columns}
# Also allow raw field selection
all_numeric_cols = fs220_df.select_dtypes(include="number").columns.tolist()

c3, c4 = st.columns([2, 1])
with c3:
    field_choice = st.selectbox("Field to plot", list(available.keys()) if available else ["(no labeled fields found)"])
with c4:
    chart_type = st.selectbox("Chart type", ["Line", "Bar", "Area"])

field_col = available.get(field_choice)

if not field_col:
    no_data_msg(f"Field '{field_choice}' not found in data.")
    st.stop()

# ── Build series ──────────────────────────────────────────────────────────────
id_col = next((c for c in fs220_df.columns if "cu_number" in c.lower()), fs220_df.columns[1])
profile_df = load_profile()

def cu_display_name(cu_num):
    if profile_df.empty:
        return f"CU {cu_num}"
    id_c = next((c for c in profile_df.columns if "cu_number" in c.lower()), None)
    if id_c is None:
        return f"CU {cu_num}"
    match = profile_df[profile_df[id_c].astype(str) == str(cu_num)]
    if match.empty:
        return f"CU {cu_num}"
    name_col = next((c for c in profile_df.columns if "cu_name" in c.lower()), None)
    return match.iloc[0][name_col] if name_col else f"CU {cu_num}"

# ── Chart ─────────────────────────────────────────────────────────────────────
fig = go.Figure()
COLORS = ["#388bfd", "#f0883e", "#3fb950", "#d29922"]

for i, cu_num in enumerate(selected_cus):
    cu_data = fs220_df[fs220_df[id_col].astype(str) == str(cu_num)].copy()
    if cu_data.empty:
        continue
    cu_data = cu_data.sort_values("quarter")
    name = cu_display_name(cu_num)
    x    = cu_data["quarter"].tolist()
    y    = pd.to_numeric(cu_data[field_col], errors="coerce").tolist()
    color = COLORS[i % len(COLORS)]

    if chart_type == "Line":
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines+markers", name=name,
                                  line=dict(color=color, width=2), marker=dict(size=7)))
    elif chart_type == "Bar":
        fig.add_trace(go.Bar(x=x, y=y, name=name, marker_color=color))
    elif chart_type == "Area":
        fig.add_trace(go.Scatter(x=x, y=y, mode="lines", name=name,
                                  fill="tozeroy", line=dict(color=color, width=2),
                                  fillcolor=color.replace(")", ",0.15)").replace("rgb", "rgba")))

fig.update_layout(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="#0d1117",
    font_color="#e6edf3",
    height=420,
    hovermode="x unified",
    legend=dict(orientation="h", y=-0.15),
    yaxis=dict(gridcolor="#21262d"),
    xaxis=dict(gridcolor="#21262d"),
    margin=dict(l=20, r=20, t=30, b=20),
    title=dict(text=field_choice, font=dict(size=14), x=0),
)
st.plotly_chart(fig, use_container_width=True)

# ── Underlying data table ─────────────────────────────────────────────────────
with st.expander("View underlying data"):
    rows_out = []
    for cu_num in selected_cus:
        cu_data = fs220_df[fs220_df[id_col].astype(str) == str(cu_num)][["quarter", field_col]].copy()
        cu_data.insert(0, "Credit Union", cu_display_name(cu_num))
        rows_out.append(cu_data)
    if rows_out:
        st.dataframe(pd.concat(rows_out), use_container_width=True, hide_index=True)
