"""
pages/5_Admin.py
─────────────────
Admin panel — run ETL ingest from within Streamlit.
Lets you point at a folder of NCUA .txt files, name the quarter, and load.
"""

import streamlit as st
import subprocess
import sys
from pathlib import Path
from utils.loader import get_quarters, data_is_loaded

st.set_page_config(page_title="Admin | NCUA Dashboard", layout="wide")
st.title("⚙️ Admin — Data Management")

# ── Status ────────────────────────────────────────────────────────────────────
st.markdown("### Loaded quarters")
quarters = get_quarters()
if quarters:
    for q in quarters:
        st.success(f"✓ {q}", icon="📅")
else:
    st.warning("No data loaded yet.", icon="⚠️")

st.markdown("---")

# ── Ingest form ───────────────────────────────────────────────────────────────
st.markdown("### Load a new quarter")
st.markdown("""
Drop your NCUA quarterly `.txt` files into a folder in this repo
(e.g. `data/raw/2024Q3/`) then fill in the details below and click **Run Ingest**.
""")

with st.form("ingest_form"):
    col1, col2 = st.columns(2)
    with col1:
        quarter_input = st.text_input(
            "Quarter label",
            placeholder="e.g. 2024Q3",
            help="This label will tag all rows. Use YYYYQN format."
        )
    with col2:
        data_dir_input = st.text_input(
            "Path to .txt files",
            value="data/raw",
            help="Relative path from repo root to the folder containing the NCUA .txt files."
        )

    submitted = st.form_submit_button("▶ Run Ingest", type="primary")

if submitted:
    if not quarter_input:
        st.error("Please enter a quarter label (e.g. 2024Q3).")
    elif not Path(data_dir_input).exists():
        st.error(f"Directory not found: `{data_dir_input}`")
    else:
        with st.spinner(f"Ingesting {quarter_input} from {data_dir_input}…"):
            result = subprocess.run(
                [sys.executable, "etl/ingest.py",
                 "--quarter",  quarter_input,
                 "--data-dir", data_dir_input],
                capture_output=True, text=True
            )
        if result.returncode == 0:
            st.success("✅ Ingest complete! Reload the page to see updated data.")
            st.code(result.stdout)
            st.cache_data.clear()
        else:
            st.error("❌ Ingest failed. See error output below.")
            st.code(result.stderr)

st.markdown("---")

# ── File inventory ────────────────────────────────────────────────────────────
st.markdown("### Processed file inventory")
processed = Path("data/processed")
if processed.exists():
    files = sorted(processed.glob("*.parquet"))
    if files:
        import pandas as pd
        rows = []
        for f in files:
            try:
                df = pd.read_parquet(f, columns=["quarter"])
                qtrs = sorted(df["quarter"].unique().tolist())
            except Exception:
                qtrs = ["(unreadable)"]
            rows.append({"File": f.name, "Rows": f.stat().st_size // 1024, "Quarters": ", ".join(qtrs)})
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
    else:
        st.caption("No parquet files yet.")
else:
    st.caption("data/processed/ does not exist yet — it will be created on first ingest.")

st.markdown("---")
st.markdown("### Clear cache")
if st.button("🗑️ Clear Streamlit data cache"):
    st.cache_data.clear()
    st.success("Cache cleared.")
